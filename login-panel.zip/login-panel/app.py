import os, json, secrets, time, threading
from flask import Flask, request, jsonify, render_template, make_response
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")          # folder ini tersimpan di panel Pterodactyl
USERS_FILE = os.path.join(DATA, "users.json")
SESS_FILE = os.path.join(DATA, "sessions.json")
SESSION_DAYS = 365
COOKIE = "sid"

DEFAULT_USER = os.environ.get("APP_USER", "root")
DEFAULT_PASS = os.environ.get("APP_PASS", "test123")

app = Flask(__name__)
lock = threading.Lock()
fails = {}  # anti brute-force sederhana: ip -> (jumlah, waktu_terakhir)


def read(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)


def init_data():
    os.makedirs(DATA, exist_ok=True)
    users = read(USERS_FILE, None)
    if not users:
        write(USERS_FILE, {DEFAULT_USER: {"hash": generate_password_hash(DEFAULT_PASS),
                                          "created": int(time.time())}})
    if not os.path.exists(SESS_FILE):
        write(SESS_FILE, {})


def current_user():
    sid = request.cookies.get(COOKIE)
    if not sid:
        return None
    with lock:
        sessions = read(SESS_FILE, {})
        s = sessions.get(sid)
        if not s:
            return None
        if s["exp"] < time.time():
            sessions.pop(sid, None)
            write(SESS_FILE, sessions)
            return None
        return s["user"]


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/me")
def me():
    u = current_user()
    return jsonify(logged_in=bool(u), user=u)


@app.post("/api/login")
def login():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "?").split(",")[0].strip()
    count, last = fails.get(ip, (0, 0))
    if count >= 5 and time.time() - last < 60:
        return jsonify(ok=False, error="Terlalu banyak percobaan. Coba lagi 1 menit."), 429

    body = request.get_json(silent=True) or {}
    username = str(body.get("username", "")).strip()
    password = str(body.get("password", ""))

    with lock:
        users = read(USERS_FILE, {})
        u = users.get(username)
        valid = bool(u) and check_password_hash(u["hash"], password)
        if not valid:
            fails[ip] = (count + 1, time.time())
            return jsonify(ok=False, error="Username atau password salah."), 401
        fails.pop(ip, None)
        sid = secrets.token_urlsafe(32)
        sessions = read(SESS_FILE, {})
        now = time.time()
        sessions = {k: v for k, v in sessions.items() if v["exp"] > now}
        sessions[sid] = {"user": username, "exp": now + SESSION_DAYS * 86400}
        write(SESS_FILE, sessions)

    resp = make_response(jsonify(ok=True, user=username))
    secure = request.is_secure or request.headers.get("X-Forwarded-Proto") == "https"
    resp.set_cookie(COOKIE, sid, max_age=SESSION_DAYS * 86400, httponly=True,
                    samesite="Lax", secure=secure)
    return resp


@app.post("/api/logout")
def logout():
    sid = request.cookies.get(COOKIE)
    if sid:
        with lock:
            sessions = read(SESS_FILE, {})
            sessions.pop(sid, None)
            write(SESS_FILE, sessions)
    resp = make_response(jsonify(ok=True))
    resp.delete_cookie(COOKIE)
    return resp


init_data()

if __name__ == "__main__":
    port = int(os.environ.get("SERVER_PORT") or os.environ.get("PORT") or 8080)
    app.run(host="0.0.0.0", port=port)
