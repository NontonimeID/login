# Login Panel (Flask)

Web login sederhana: HTML + CSS + JavaScript + Python (Flask).
Data disimpan di folder `data/` pada server (Pterodactyl), jadi sesi login tetap ada
saat halaman di-refresh. Hapus folder `data/` di panel untuk mereset semuanya.

## Akun default
- Username: `root`
- Password: `test123`

Bisa diganti lewat variabel environment `APP_USER` dan `APP_PASS`
(hanya berlaku saat `data/users.json` pertama kali dibuat).

## Struktur
- `app.py` - backend Flask + penyimpanan JSON
- `templates/index.html` - halaman
- `static/style.css`, `static/app.js` - tampilan & logika
- `data/` - dibuat otomatis (tidak masuk GitHub)

## Deploy di Pterodactyl
1. Upload semua file ke File Manager (atau `git clone` repo GitHub-mu).
2. Startup: gunakan egg Python Generic. Set **APP PY FILE** = `app.py`,
   **PY PACKAGES** / requirements file = `requirements.txt`.
3. Pastikan port server di tab Network sudah dialokasikan (app membaca `SERVER_PORT` otomatis).
4. Start server, lalu buka `http://IP:PORT`.

## Sambung domain
Arahkan domain (A record) ke IP node Pterodactyl, lalu pasang reverse proxy
(Nginx / Caddy / Cloudflare) dari domain ke `IP:PORT`. Dengan HTTPS, cookie otomatis ditandai `Secure`.

## Reset
- Hapus `data/sessions.json` -> semua orang harus login ulang.
- Hapus `data/users.json` -> akun dibuat ulang ke default.
