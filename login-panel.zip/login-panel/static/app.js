const $ = (id) => document.getElementById(id);
const views = { boot: $("boot"), login: $("loginView"), home: $("homeView") };

function show(name) {
  Object.entries(views).forEach(([k, el]) => el.classList.toggle("hidden", k !== name));
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    method: options.method || "GET",
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch (_) {}
  return { status: res.status, data };
}

async function init() {
  try {
    const { data } = await api("/api/me");
    if (data.logged_in) { $("who").textContent = data.user; show("home"); }
    else show("login");
  } catch (_) { show("login"); }
}

$("toggle").addEventListener("click", () => {
  const p = $("password");
  p.type = p.type === "password" ? "text" : "password";
});

$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = $("submit"), err = $("error");
  err.textContent = "";
  btn.disabled = true; btn.classList.add("loading");
  try {
    const { data } = await api("/api/login", {
      method: "POST",
      body: { username: $("username").value, password: $("password").value },
    });
    if (data.ok) {
      $("who").textContent = data.user;
      $("password").value = "";
      show("home");
    } else {
      err.textContent = data.error || "Login gagal.";
      const card = $("loginView");
      card.classList.remove("shake"); void card.offsetWidth; card.classList.add("shake");
    }
  } catch (_) {
    err.textContent = "Tidak bisa terhubung ke server.";
  }
  btn.disabled = false; btn.classList.remove("loading");
});

$("logout").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST" });
  show("login");
});

init();
